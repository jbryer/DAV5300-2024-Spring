Depoloyed app at https://openintro.shinyapps.io/inf_for_categorical_data/.
